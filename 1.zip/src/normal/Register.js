import { StyleSheet, Text, View } from "react-native";
import React from "react";

export default function Register() {
  return (
    <View>
      <Text>Register</Text>
    </View>
  );
}

// blink rate
// digital wellbing
// eye health
// distance

const styles = StyleSheet.create({});

import { StyleSheet, Text, View } from "react-native";
import React from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import DrawerNavigator from "../drawer/DrawerNavigator";

export default function Login() {
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <Text>hello</Text>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({});

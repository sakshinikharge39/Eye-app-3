import { StyleSheet, Text, View } from "react-native";
import React from "react";

export default function Screen1() {
  return (
    <View>
      <Text>Screen1</Text>
    </View>
  );
}

const styles = StyleSheet.create({});

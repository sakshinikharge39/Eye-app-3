import { StyleSheet, Text, View } from "react-native";
import React from "react";

export default function Screen2() {
  return (
    <View>
      <Text>Screen2</Text>
    </View>
  );
}

const styles = StyleSheet.create({});
